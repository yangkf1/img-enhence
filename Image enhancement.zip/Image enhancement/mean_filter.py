#均值滤波器

import cv2
import copy
import random
import imutils
import numpy as np
 
img=cv2.imread('C:\\Users\\yang\\Desktop\\Image enhancement\\images\\1.jpg')
gray_img=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
 
#利用OpenCV提供函数实现均值滤波
blur_img=cv2.blur(gray_img,(3,3))
 
#在灰度图上手动实现均值滤波器
gray_avg_img=copy.deepcopy(gray_img)   #在复制图像上修改，首先复制一份
for i in range(1,gray_img.shape[0]-1):
    for j in range(1,gray_img.shape[1]-1):
        sum_pix=sum([gray_img[l,k] for l in range(i-1,i+2) for k in range(j-1,j+2)]) #range函数写到i+2实际遍历到i+1，j+1同理
        gray_avg_img[i,j]=int(sum_pix/9) #9个点求和除均值，均值滤波实现
 
#在RGB彩色图上手动实现均值滤波
rgb_avg_img=copy.deepcopy(img)
for i in range(1,img.shape[0]-1):
    for j in range(1,img.shape[1]-1):  #RGB三个通道，实现三次
        sum_b_pix=sum([img[l,k,0] for l in range(i-1,i+2) for k in range(j-1,j+2)])
        sum_g_pix = sum([img[l, k, 1] for l in range(i - 1, i + 2) for k in range(j - 1, j + 2)])
        sum_r_pix = sum([img[l, k, 2] for l in range(i - 1, i + 2) for k in range(j - 1, j + 2)])
        rgb_avg_img[i,j]=[int(sum_b_pix/9),int(sum_g_pix/9),int(sum_r_pix/9)]
 
cv2.imshow('origin image',imutils.resize(img,500))
cv2.imshow('gray image',imutils.resize(gray_img,500))
cv2.imshow('blur image',imutils.resize(blur_img,500))
cv2.imshow('gray average image',imutils.resize(gray_avg_img,500))
cv2.imshow('rgb average image',imutils.resize(rgb_avg_img,500))
if cv2.waitKey(0) == 27:
    cv2.destroyAllWindows()